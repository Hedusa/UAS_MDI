package com.example.prak_dbs

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
